import json
import os
import requests
from urllib.parse import urlparse
#https://164custom.com/hot-wheels/case-k/2024.html
# Create a directory to store the images if it doesn't exist
images_dir = "images"
if not os.path.exists(images_dir):
    os.makedirs(images_dir)
    print(f"Created directory: {images_dir}")

# Load the JSON data
try:
    with open('data.json', 'r') as f:
        data = json.load(f)
    print("Successfully loaded data.json.")
except FileNotFoundError:
    print("Error: data.json not found. Make sure it's in the same directory as this script.")
    exit()

# Function to download an image and update the JSON data
def process_car_data(car):
    """Downloads the image for a given car and updates its image path."""
    image_url = car.get("image")
    if not image_url:
        print(f"Warning: No image URL found for car: {car.get('name', 'Unknown')}")
        return

    # Handle placeholder images separately
    if "images-coming-soon-200.png" in image_url:
        # Check if the placeholder image has already been downloaded
        placeholder_filename = "images-coming-soon-200.png"
        local_path = os.path.join(images_dir, placeholder_filename)
        if not os.path.exists(local_path):
            try:
                print(f"Downloading placeholder image from {image_url}...")
                response = requests.get(image_url, timeout=10)
                response.raise_for_status()
                with open(local_path, 'wb') as img_file:
                    img_file.write(response.content)
                print(f"Saved {placeholder_filename}")
            except requests.exceptions.RequestException as e:
                print(f"Error downloading {image_url}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")
        car["image"] = local_path
        return

    try:
        # Generate a unique filename from the URL
        url_path = urlparse(image_url).path
        path_parts = url_path.strip('/').split('/')
        # The unique part is usually the two-part directory structure plus the filename
        # e.g., HW/8084/th.jpg -> HW8084th.jpg
        if len(path_parts) >= 3:
            filename = f"{path_parts[-3]}{path_parts[-2]}{path_parts[-1]}"
        else:
            filename = os.path.basename(url_path)

        local_path = os.path.join(images_dir, filename)

        # Download the image only if it doesn't already exist
        if not os.path.exists(local_path):
            print(f"Downloading {filename} from {image_url}...")
            response = requests.get(image_url, timeout=10)
            response.raise_for_status()  # Raise an HTTPError for bad responses (4xx or 5xx)

            with open(local_path, 'wb') as img_file:
                img_file.write(response.content)
            print(f"Saved {filename}")

        # Update the image path in the JSON data
        car["image"] = local_path
    except requests.exceptions.RequestException as e:
        print(f"Error downloading {image_url}: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Iterate through all cases and process each car
for year_key in data:
    for case in data[year_key]["cases"]:
        # Process the Treasure Hunt and Super Treasure Hunt cars
        process_car_data(case["th"])
        process_car_data(case["sth"])
        # Process the main list of cars
        for car in case["cars"]:
            process_car_data(car)

# Save the updated JSON data back to the file
try:
    with open('data.json', 'w') as f:
        json.dump(data, f, indent=2)
    print("\nSuccessfully updated data.json with local image paths.")
except Exception as e:
    print(f"Error saving updated data.json: {e}")