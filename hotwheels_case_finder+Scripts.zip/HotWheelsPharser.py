import json
import os
import requests
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog

# Create a directory to store the images if it doesn't exist
images_dir = "images"
if not os.path.exists(images_dir):
    os.makedirs(images_dir)

def download_and_update_image(car_data):
    """
    Downloads an image from a URL and updates the dictionary with the local path.
    Args:
        car_data (dict): A dictionary representing a car with an 'image' key.
    """
    image_url = car_data.get("image")
    if not image_url:
        print(f"Warning: No image URL found for car: {car_data.get('name', 'Unknown')}")
        return

    # Handle placeholder images separately
    if "images-coming-soon-200.png" in image_url:
        placeholder_filename = "images-coming-soon-200.png"
        local_path = os.path.join(images_dir, placeholder_filename)
        # Download the placeholder image only once
        if not os.path.exists(local_path):
            try:
                print(f"Downloading placeholder image from {image_url}...")
                response = requests.get(image_url, timeout=10)
                response.raise_for_status()
                with open(local_path, 'wb') as img_file:
                    img_file.write(response.content)
                print(f"Saved {placeholder_filename}")
            except requests.exceptions.RequestException as e:
                print(f"Error downloading {image_url}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")
        car_data["image"] = local_path
        return

    try:
        # Generate a unique filename from the URL path parts
        url_path = urlparse(image_url).path
        path_parts = url_path.strip('/').split('/')
        if len(path_parts) >= 3:
            filename = f"{path_parts[-3]}{path_parts[-2]}{path_parts[-1]}"
        else:
            filename = os.path.basename(url_path)

        local_path = os.path.join(images_dir, filename)

        # Download the image only if it doesn't already exist
        if not os.path.exists(local_path):
            print(f"Downloading {filename} from {image_url}...")
            response = requests.get(image_url, timeout=10)
            response.raise_for_status()
            with open(local_path, 'wb') as img_file:
                img_file.write(response.content)
            print(f"Saved {filename}")

        # Update the image path in the dictionary
        car_data["image"] = local_path
    except requests.exceptions.RequestException as e:
        print(f"Error downloading {image_url}: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def parse_and_save_data():
    """Parses HTML, downloads images, and saves the data to a JSON file."""
    html_content = text_area.get("1.0", tk.END)
    if not html_content.strip():
        messagebox.showwarning("Warning", "Please paste HTML content first!")
        return

    soup = BeautifulSoup(html_content, "html.parser")
    table_rows = soup.select("tbody tr")
    
    data = {}
    
    for row in table_rows:
        cols = row.find_all("td")
        if len(cols) < 10:
            continue
        
        year = cols[0].text.strip()
        name_tag = cols[2].find("a")
        name = name_tag.text.strip() if name_tag else "Unknown"
        img_tag = cols[1].find("img")
        img_url = img_tag['src'] if img_tag else ""
        case_letter = cols[9].text.strip()

        if year not in data:
            data[year] = {"cases": []}
        
        # Find or create case
        case_entry = next((c for c in data[year]["cases"] if c["letter"] == case_letter), None)
        if not case_entry:
            case_entry = {
                "letter": case_letter,
                "th": {"name": "", "image": ""},
                "sth": {"name": "", "image": ""},
                "cars": []
            }
            data[year]["cases"].append(case_entry)
        
        car_info = {
            "name": name,
            "image": img_url
        }
        
        # Download the image and update the path
        download_and_update_image(car_info)
        
        case_entry["cars"].append(car_info)
    
    # Save each case into a separate JSON file
    for year, year_data in data.items():
        for case in year_data["cases"]:
            case_letter = case["letter"]
            file_path = f"case_{case_letter}.json"
            case_json_content = json.dumps({year: {"cases": [case]}}, indent=2)
            try:
                with open(file_path, "w") as f:
                    f.write(case_json_content)
                messagebox.showinfo("Success", f"JSON data for Case {case_letter} saved successfully to {file_path}!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save JSON data for Case {case_letter}: {e}")

# GUI setup
root = tk.Tk()
root.title("Hot Wheels HTML to JSON Parser")

tk.Label(root, text="Paste your HTML here:").pack()
text_area = scrolledtext.ScrolledText(root, width=120, height=20)
text_area.pack()

tk.Button(root, text="Parse and Save Data", command=parse_and_save_data).pack(pady=5)

tk.Label(root, text="Output JSON:").pack()
text_output = scrolledtext.ScrolledText(root, width=120, height=20)
text_output.pack()

root.mainloop()