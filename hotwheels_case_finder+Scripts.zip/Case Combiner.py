import json
import os
import glob
import tkinter as tk
from tkinter import messagebox

def combine_and_save_json():
    """
    Combines multiple JSON files into a single data.json file with a GUI.
    """
    # Define the final combined data structure
    combined_data = {
        "2024": {
            "cases": []
        }
    }
    
    # Use glob to find all files matching the pattern "case_*.json"
    json_files = sorted(glob.glob("case_*.json"))
    
    if not json_files:
        messagebox.showwarning("Warning", "No JSON files found with the pattern 'case_*.json'.")
        return
        
    print(f"Found {len(json_files)} JSON files to combine.")
    
    # Iterate through each file, load its content, and append the cases
    for file_path in json_files:
        try:
            with open(file_path, 'r') as f:
                file_data = json.load(f)
            
            # Extract the cases list from the loaded file data
            for year_key in file_data:
                if "cases" in file_data[year_key]:
                    case_list = file_data[year_key]["cases"]
                    combined_data["2024"]["cases"].extend(case_list)
                    print(f"Successfully added cases from {file_path}.")
                else:
                    print(f"Warning: 'cases' key not found in {file_path}. Skipping.")
        except json.JSONDecodeError as e:
            messagebox.showerror("Error", f"Error decoding JSON from {file_path}: {e}")
            return
        except FileNotFoundError:
            messagebox.showerror("Error", f"Error: {file_path} not found.")
            return
    
    # Save the combined data to a new data.json file
    final_file_path = "data2024.json"
    try:
        with open(final_file_path, 'w') as f:
            json.dump(combined_data, f, indent=2)
        messagebox.showinfo("Success", f"Successfully combined all JSON files into {final_file_path}.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save the combined JSON file: {e}")

# GUI setup
root = tk.Tk()
root.title("JSON Combiner")

# Button to trigger the combination process
combine_button = tk.Button(root, text="Combine and Save JSON", command=combine_and_save_json)
combine_button.pack(pady=20, padx=20)

root.mainloop()

# The original function is now called by the GUI button
if __name__ == "__main__":
    # This block is now effectively managed by the GUI.
    # The combine_json_files() function is now `combine_and_save_json()` and is triggered by the button.
    pass
